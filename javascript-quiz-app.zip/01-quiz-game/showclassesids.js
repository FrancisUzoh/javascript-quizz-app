const elementsAll = document.querySelectorAll("*");

elementsAll.forEach((el) => {
  // 1. Set the red border
  if (["SCRIPT", "STYLE", "HEAD", "NOSCRIPT"].includes(el.tagName)) return;
  el.style.outline = "1px solid red";

  // 2. Only label elements that actually have an ID or Class to show
  if (el.id || el.className) {
    const label = document.createElement("div");      

    // 3. Format the text: ID in bold, classes preceded by dots
    const idPart = el.id ? `#${el.id}` : "";
    const classPart = el.classList.length > 0  ? ` .${Array.from(el.classList).join(".")}` : "";
    
    label.innerHTML = `<span style="color: #ffff00; font-weight: bold;">${idPart}</span>
        <span style="color: #ffffff;">${classPart}</span>`;    

   

    // 4. Style the label so it floats over the element
    Object.assign(label.style, {
      position: "absolute",
      backgroundColor: "red",
      color: "white",
      fontSize: "9px",
      fontWeight: "bold",
      padding: "1px 3px",
      zIndex: "99999",
      pointerEvents: "none", // Important: allows you to click "through" the label
      lineHeight: "1",
      whiteSpace: "nowrap",
    });

    // 5. Place it on the page
    el.style.position = "relative"; // Ensures the label stays near the element
    el.prepend(label);
      
  }
});
