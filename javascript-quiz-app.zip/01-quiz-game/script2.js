// --- DOM Elements (The Bridges to HTML) ---

// Links to <div id="start-screen" class="screen active">
const startScreen = document.getElementById("start-screen");

// Links to <div id="quiz-screen" class="screen">
const quizScreen = document.getElementById("quiz-screen");

// Links to <div id="result-screen" class="screen">
const resultScreen = document.getElementById("result-screen");

// Links to <button id="start-btn">
const startButton = document.getElementById("start-btn");

// Links to <h2 id="question-text">
const questionText = document.getElementById("question-text");

// Links to <div id="answers-container" class="answers-container">
const answersContainer = document.getElementById("answers-container");

// Links to <span id="current-question">
const currentQuestionSpan = document.getElementById("current-question");

// Links to <span id="total-questions">
const totalQuestionsSpan = document.getElementById("total-questions");

// Links to <span id="score">
const scoreSpan = document.getElementById("score");

// Links to <span id="final-score">
const finalScoreSpan = document.getElementById("final-score");

// Links to <span id="max-score">
const maxScoreSpan = document.getElementById("max-score");

// Links to <div id="result-message">
const resultMessage = document.getElementById("result-message");

// Links to <button id="restart-btn">
const restartButton = document.getElementById("restart-btn");

// Links to <div id="progress" class="progress">
const progressBar = document.getElementById("progress");

// --- QUIZ DATA ---
const quizQuestions = [
    {
        question: "What is the capital of France?",
        answers: [
            { text: "London", correct: false },
            { text: "Berlin", correct: false },
            { text: "Paris", correct: true },
            { text: "Madrid", correct: false },
        ],
    },
    // ... other questions
];

// --- QUIZ STATE VARS ---
let currentQuestionIndex = 0;
let score = 0;
let answersDisabled = false;

// Sets text for <span id="total-questions"> and <span id="max-score">
totalQuestionsSpan.textContent = quizQuestions.length;
maxScoreSpan.textContent = quizQuestions.length;

// --- EVENT LISTENERS ---
// Listens for clicks on <button id="start-btn">
startButton.addEventListener("click", startQuiz);
// Listens for clicks on <button id="restart-btn">
restartButton.addEventListener("click", restartQuiz);

function startQuiz() {
    currentQuestionIndex = 0;
    score = 0;

    // Resets text inside <span id="score"> to 0
    scoreSpan.textContent = 0;

    // Uses .classList to toggle the .active class defined in style.css
    startScreen.classList.remove("active"); // Hides <div id="start-screen">
    quizScreen.classList.add("active");    // Shows <div id="quiz-screen">

    showQuestion();
}

function showQuestion() {
    answersDisabled = false;
    const currentQuestion = quizQuestions[currentQuestionIndex];
    const delayTime = 150;

    // Updates text inside <span id="current-question">
    currentQuestionSpan.textContent = currentQuestionIndex + 1;

    // Calculates and sets the CSS 'width' style of <div id="progress">
    const progressPercent = (currentQuestionIndex / quizQuestions.length) * 100;
    progressBar.style.width = progressPercent + "%";

    // Injects the question string into <h2 id="question-text">
    questionText.textContent = currentQuestion.question;

    // Clears all existing HTML content inside <div id="answers-container">
    answersContainer.innerHTML = "";

    currentQuestion.answers.forEach((answer, index) => {
        // Creates a brand new <button> element
        const button = document.createElement("button");
        button.textContent = answer.text;

        // Adds the .answer-btn class from style.css for styling
        button.classList.add("answer-btn");

        // Stores the boolean in a data-attribute: <button data-correct="...">
        button.dataset.correct = answer.correct;

        button.addEventListener("click", selectAnswer);

        // Adds .fade-in class from style.css to trigger the animation
        setTimeout(() => {
            button.classList.add("fade-in");
        }, index * delayTime);

        // Places the new button inside <div id="answers-container">
        answersContainer.appendChild(button);
    });
}

function selectAnswer(event) {
    if (answersDisabled) return;
    answersDisabled = true;

    const selectedButton = event.target;
    const isCorrect = selectedButton.dataset.correct === "true";

    // Converts children of <div id="answers-container"> to an array to loop through them
    Array.from(answersContainer.children).forEach((button) => {
        // Adds .correct or .incorrect classes from style.css based on logic
        if (button.dataset.correct === "true") {
            button.classList.add("correct");
        } else if (button === selectedButton) {
            button.classList.add("incorrect");
        }
    });

    if (isCorrect) {
        score++;
        // Updates the text inside <span id="score">
        scoreSpan.textContent = score;
    }

    setTimeout(() => {
        currentQuestionIndex++;

        if (currentQuestionIndex < quizQuestions.length) {
            showQuestion();
        } else {
            showResults();
        }
    }, 2000);
}

function showResults() {
    // Swaps the .active class from <div id="quiz-screen"> to <div id="result-screen">
    quizScreen.classList.remove("active");
    resultScreen.classList.add("active");

    // Updates text inside <span id="final-score">
    finalScoreSpan.textContent = score;

    const percentage = (score / quizQuestions.length) * 100;

    // Conditional logic to update text inside <div id="result-message">
    if (percentage === 100) {
        resultMessage.textContent = "Perfect! You're a genius!";
    } else if (percentage >= 80) {
        resultMessage.textContent = "Great job! You know your stuff!";
    } else if (percentage >= 60) {
        resultMessage.textContent = "Good effort! Keep learning!";
    } else if (percentage >= 40) {
        resultMessage.textContent = "Not bad! Try again to improve!";
    } else {
        resultMessage.textContent = "Keep studying! You'll get better!";
    }
}

function restartQuiz() {
    // Removes .active from <div id="result-screen"> before starting over
    resultScreen.classList.remove("active");
    startQuiz();
}