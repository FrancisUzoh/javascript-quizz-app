module.exports = [
  {
    ignores: ["node_modules", "dist", ".DS_Store"],
  },
  {
    files: ["**/*.js"],
    languageOptions: {
      ecmaVersion: 12,
      sourceType: "module",
      globals: {
        window: "readonly",
        document: "readonly",
        navigator: "readonly",
      },
    },
    rules: {
      "quotes": ["error", "double"],
      "semi": ["error", "always"],
      "indent": ["error", 2],
      "no-unused-vars": ["warn", { "args": "none", "ignoreRestSiblings": true }]
    }
  }
];
