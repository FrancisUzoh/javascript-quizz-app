currentQuestion.answers.map((answer, index) => {
    const button = document.createElement("button");
    button.textContent = answer.text;
    button.classList.add("answer-btn");

    // what is dataset? it's a property of the button element that allows you to store custom data
    button.dataset.correct = answer.correct;

    button.addEventListener("click", selectAnswer);
    
    setTimeout(() => {
    button.classList.add("fade-in");
    }, index * delayTime);

    answersContainer.appendChild(button);
  });
}